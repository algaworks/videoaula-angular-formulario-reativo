insert into contato (id, nome, email) values (null, 'Eduardo', 'eduardo@email.com');
insert into contato (id, nome, email) values (null, 'Ana', 'ana@email.com');
insert into contato (id, nome, email) values (null, 'Thiago', 'thiago@email.com');
insert into contato (id, nome, email) values (null, 'Júnior', 'junior@email.com');
insert into contato (id, nome, email) values (null, 'Priscila', 'priscila@email.com');
insert into contato (id, nome, email) values (null, 'Camila', 'camila@email.com');
insert into contato (id, nome, email) values (null, 'Afonso', 'afonso@email.com');